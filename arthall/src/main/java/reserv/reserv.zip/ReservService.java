package reserv;

import java.util.List;

public interface ReservService {
	public List<ReservVO> list(ReservVO param);

}
